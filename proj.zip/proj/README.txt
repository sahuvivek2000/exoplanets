A Pen created at CodePen.io. You can find this one at https://codepen.io/peiche/pen/vhqym.

 A popup window/modal window experiment based on the :target pseudoclass.

The first popup stays open until you click the "X" to close.
The second will close when you click anywhere outside the popup.