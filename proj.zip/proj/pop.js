// When the user clicks on div, open the popup
function myFunction() {
  var popup = document.getElementById("myPopup");
  popup.classList.toggle("show");
}
function myFunction1() {
  var popup = document.getElementById("myPopup");
  popup.classList.toggle("show");
}